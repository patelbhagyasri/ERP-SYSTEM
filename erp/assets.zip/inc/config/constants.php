<?php
	// Root url for the site
	define('ROOT_URL', 'https://aics.ac.in/erp_system/');
	
	
	// Database parameters
	// Data source name
	define('DSN', 'mysql:host=localhost;dbname=aicsaci1_shop_inventory');
	
	// Hostname
	define('DB_HOST', 'localhost');
	
	// DB user
	define('DB_USER', 'aicsaci1_erpssaiet');
	
	// DB password
	define('DB_PASSWORD', 'tm{T;vM-P&AS');
	
	// DB name
	define('DB_NAME', 'aicsaci1_shop_inventory');
?>